--Makes sure that the mouse has the largest layer
tweak_data.gui.MOUSE_LAYER = 9999999999