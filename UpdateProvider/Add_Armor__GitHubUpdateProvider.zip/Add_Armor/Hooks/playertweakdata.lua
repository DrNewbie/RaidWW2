Hooks:PostHook(PlayerTweakData, "_init_default_class_tweak_data", "F_"..Idstring("PostHook:PlayerTweakData:_init_default_class_tweak_data:Add Armor"):key(), function(self)
	self.class_defaults.default.damage.BASE_ARMOR = 20
end)